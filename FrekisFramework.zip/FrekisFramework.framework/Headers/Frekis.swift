//
//  Frekis.swift
//  FrekisFramework
//
//  Created by Bhargav on 14/07/20.
//  Copyright © 2020 Bhargav. All rights reserved.
//

import Foundation

let kWLBLEM = WLBLEManagement.shareInstance()!
 let kWLCommonTool = WLCommonTool.shareLocation()!
 let kFMDBManage = FMDBManage.shareIntance()!

struct AppMessages{
    static let InternetErrorMessage     =   "Please check internet connection and try again!"
    static let BluetoothErrorMessage    =   "Please turn on bluetooth!"
    static let PasswordConfirmationMessage = "If you register your lock in frekis, it will not able to use in other platforms. If you wish to register in frekis then write a password here."
}
@objc
public class Frekis : NSObject {
    
  var scannerTimer : Timer!

    
        //MARK:- SHAREDMANAGER
         static let shared : Frekis = {
            
             let instance = Frekis()
    //        instance.setUpPaymentIntet()
             return instance
         }()
    
    let ScannerWaitingTime = 10
    @objc var mac : String = ""
    
    let DefaultLockPassword = "123456"
    let DefaultNewPassword = "721997"
    
    public override init() {}
    
    public func log(message: String) {
        print("Log message: ", message)
    }
    
     func detectDevice(with lockID : String, detectedDevice : @escaping(_ peripheral : CBPeripheral?, _ fmBLEModel : FMBLEModel ) -> ()){
            
            if !kWLBLEM.state {
                print("Please turn on bluetooth!")
//                AppNotification.showWarningMessage(AppMessages.BluetoothErrorMessage)
                return
            }
            
            kFMDBManage.deleteAllFMrecordModels()
            kFMDBManage.deleteAllFMBLEModel()
            print("Scanning for device with id : \(lockID)")
    //        ProgressView.show()
//            UIViewController.topMostViewController.startLoader()
            kWLBLEM.scanBLE(withIsAutoScan: true) { (peripheral, FMBLEModel) in
                if let fmBLEModel = FMBLEModel{
                    
                    if fmBLEModel.isConnected{
                        kWLBLEM.disconnectPeripheral(fmBLEModel.peripheral)
                    }
                    var x = lockID
                    x.removeFirst(4)
                    
                    if fmBLEModel.mac.contains(x){
                        kWLBLEM.stopScan()
                        kWLBLEM.connect(peripheral) { (periPheral) in
                            print("Device detected.")
                            dismissScannerTimer()
                            detectedDevice(periPheral, fmBLEModel)
                        }
                    } else { showScannerTimer() }
                }
            }
        }
        
         func connect(peripheral : CBPeripheral?, fmBLEModel : FMBLEModel, password : String, connectedDevice : @escaping(_ fmBLEModel : FMBLEModel? ) -> ()){
            if !kWLBLEM.state {
                AppNotification.showWarningMessage(AppMessages.BluetoothErrorMessage)
                return
            }
            
    //        ProgressView.show(message: "Connecting device..")
//            UIViewController.topMostViewController.startLoader(message: "Connecting device..")
            print("connecting from bleHelper \(fmBLEModel.mac ?? "")....")
            print("Connecting Device : \(fmBLEModel.mac ?? "")")
            fmBLEModel.password = password
            kWLBLEM.tempPassword = password
            
            kWLBLEM.connect(peripheral, fmBLEModel: fmBLEModel)
            kWLBLEM.connectedBlock = { bleModel in
                  DispatchQueue.main.async {
    //                              ProgressView.dismiss()
//                    UIViewController.topMostViewController.hideLoader()
                }
                kWLBLEM.stopScan()
                if bleModel == nil{
                    print("Unable to connect due to wrong password.")
                    
                    connectedDevice(nil)
                }else if let blemodel = bleModel , blemodel.isConnected{
                    self.setAutoUnlock(isOn: false, fmBLEModel: blemodel)
                    connectedDevice(blemodel)
                    print("Device connected.")
                }
            }
            
    //        kWLBLEM.disconnectedBlock = {
    //
    //        }
        }
        
         func unlockDevice(fmBLEModel : FMBLEModel, isSuccess : @escaping (_ success : Bool) -> ()){
            print("Unlocking device \(fmBLEModel.mac ?? "").")
            var isNeedToCallBlock = true
            //        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (_) in
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.unlock(withToken: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
            kWLBLEM.updateUIBlock = {
                if let lockArray = kWLBLEM.bleArray {
                    for lockObj in lockArray {
                        if (lockObj as! FMBLEModel).mac == fmBLEModel.mac  {
                            print("Lock")
                            if (lockObj as! FMBLEModel).isConnected == false {
                                 if isNeedToCallBlock  {
                                    isNeedToCallBlock = false
                                    isSuccess(true)
                                }
                            }
                        }
                    }
                }else{
                    
                }
                
                
            }
            kWLBLEM.lockUnlocked = { (aPeripheral,bleModel,isUnlocked) in
                if isUnlocked {
                    print("Unlocked device \(fmBLEModel.mac ?? "").")
                    if isNeedToCallBlock  {
                        isNeedToCallBlock = false
                                       isSuccess(true)
                    }
                   
                }else{
                    
                }
            }
            
            //               }
        }
        
         func changeLockPassword(oldPassword : String, newPassword : String, fmBLEModel : FMBLEModel, isSuccess : @escaping (_ success : Bool) -> ()){
            print("Old = \(oldPassword)   --  New = \(newPassword)")
            print("current password = \(String(describing: fmBLEModel.password))")
            //        if fmBLEModel.password != oldPassword{
            //            AppNotification.showWarningMessage("Old password does not match.")
            //            isSuccess(false)
            //            return
            //        }
            
    //        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (_) in
                kWLBLEM.tempPassword = newPassword
                kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.changePassword(withPasswordOld: oldPassword, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
                kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.changePassword(withPasswordNew: newPassword, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
                kWLBLEM.passwordChange = { (aPeripheral,bleModel,isPasswordChange) in
                    if isPasswordChange {
                         print("******   Password Updated to \(newPassword)    ******")
                                   print("Device password updated to \(newPassword).")
                        isSuccess(true)
                    }else{
                          isSuccess(false)
                    }
                }
               
    //            isSuccess(true)
    //        }
        }
        
         func setAutoUnlock(isOn : Bool, fmBLEModel : FMBLEModel){
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.setAutoUnlockWithOn(isOn, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
        }
        
         func setVibrationAlert(isOn : Bool, fmBLEModel : FMBLEModel){
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.setVibrationAlertWithOn(isOn, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
        }
        
         func setConsignmentMode(isOn : Bool, fmBLEModel : FMBLEModel){
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.setConsignModelWithOn(isOn, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
        }
        
         func setLockName(name : String, fmBLEModel : FMBLEModel){
            var lockName = name
            if lockName.count < 16{
                let count = 16-lockName.count
                for _ in 0..<count{
                    lockName = lockName.appending(" ")
                }
            }
            
            let str1 = (lockName as NSString).substring(with: NSRange(location: 0, length: 8))
            let str2 = (lockName as NSString).substring(with: NSRange(location: 8, length: 8))
            
            kWLBLEM.tempName = lockName
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.changeBLEName(withName1: str1, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
            kWLBLEM.write(withWrite: fmBLEModel.writeCharacteristic, data: BLETools.changeBLEName(withName2: str2, token: fmBLEModel.tokenData), peripheral: fmBLEModel.peripheral)
        }
}
func showScannerTimer(){
    if Frekis.shared.scannerTimer != nil && Frekis.shared.scannerTimer.isValid{
        return
    }

    var time = 0
//    ProgressView.show(message: "Finding device..")
//    UIViewController.topMostViewController.startLoader(message: "Finding device..")
    Frekis.shared.scannerTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: { (_) in
        time += 1
        if time == Frekis.shared.ScannerWaitingTime{
            kWLCommonTool.showMessage("Unable to find device, Please try again!")
            dismissScannerTimer()
        }
    })
}

func dismissScannerTimer(){
  
    if Frekis.shared.scannerTimer != nil && Frekis.shared.scannerTimer.isValid{
        Frekis.shared.scannerTimer.invalidate()
    }
}
