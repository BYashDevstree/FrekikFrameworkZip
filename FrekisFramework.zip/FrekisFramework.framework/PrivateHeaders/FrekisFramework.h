//
//  FrekisFramework.h
//  FrekisFramework
//
//  Created by Bhargav on 14/07/20.
//  Copyright © 2020 Bhargav. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FrekisFramework.
FOUNDATION_EXPORT double FrekisFrameworkVersionNumber;

//! Project version string for FrekisFramework.
FOUNDATION_EXPORT const unsigned char FrekisFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FrekisFramework/PublicHeader.h>
#import "FrekisFramework/FrekisFramework-umbrella.h"


